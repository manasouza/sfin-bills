import base64
import json
import functions_framework
import gspread
import spreadsheet

from datetime import datetime
from google.cloud import storage

import logging
logging.basicConfig(level=logging.INFO)
# check how that will work into CF
import locale
locale.setlocale(locale.LC_ALL, 'pt_BR.UTF-8')

storage_client = storage.Client()

HEADER_MONTH_ROW=2
CATEGORY_COLUMN=1
WORKSHEET='Projeção 2025'

DAY_START=15
FORMULAS = {
  '15': {
    'Curto Prazo / Reserva de emergência' : '=200'
  },
  '23': {
    'Aluguel/Financiamento/Seguro' : '=4872,54+4,2-Aluguel!B15',
    'Impostos/Multas' : '=394,97'
  },
  '25': {
    'Serv. On demand/Cloud' : '=0'
  }
}

# Triggered from a message on a Cloud Pub/Sub topic.
@functions_framework.cloud_event
def hello_pubsub(cloud_event):
    # Print out the data from Pub/Sub, to prove that it worked
    print(base64.b64decode(cloud_event.data["message"]["data"]))

    # set up spreadsheet
    sps = spreadsheet.SpreadsheetIntegration('14Isj1FGGDTmq_lzjqrb_pkU58rRXEEQTpABOMaqGxKY', cred_remote_function=_get_gcs_auth_key)
    sps.set_main_worksheet(WORKSHEET)
    # REF: https://www.programiz.com/python-programming/datetime/strftime
    current_month = datetime.now().strftime('%B/%Y').capitalize()
    logging.info('checking data for %s', current_month)
    m_cell = sps.get_cell_by_column_value(current_month, HEADER_MONTH_ROW)
    day_of_month = int(datetime.now().strftime('%d'))
    if day_of_month in FORMULAS:
      if m_cell:
        for k,v in FORMULAS[day_of_month]:
          c_cell = sps.get_cell_by_row_value(k, CATEGORY_COLUMN)
          # import ipdb; ipdb.set_trace()
          # check if it's already filled
          cell_value = sps.get_cell_value(c_cell.row, m_cell.col)
          logging.info('setting value: %s', c_cell)
          # This comparison was failing due  line 50, in hello_pubsub if v not in cell_value: TypeError: argument of type 'NoneType' is not iterable 
          # if v not in cell_value:
          #   # then update it
          #   sps.update_cell_value(c_cell.row, m_cell.col, v)
          #   logging.info('%s updated with "%s"', c_cell, v)
          # else:
          #   logging.info('row %s/column %s already has value set: %s', c_cell.row, m_cell.col, cell_value)
          logging.info('%s updated with "%s"', c_cell, v)
          sps.update_cell_value(c_cell.row, m_cell.col, v)
      else:
        logging.info('cell not found for %s at row %s', current_month, HEADER_MONTH_ROW)
    else:
      logging.info('day of month not supported yet: %s', day_of_month)


def _get_gcs_auth_key():
    # TODO: add as env var
    print('load creds from GCS')
    sa_name = 'SmartFinance-Bills-Beta-eb6d6507173d.json'
    sa_bucket = 'sfinbills'
    bucket = storage_client.get_bucket(sa_bucket)
    # List objects with the given prefix.
    for index, blob in enumerate(bucket.list_blobs()):
        print(blob.name)
        if blob.name == sa_name:
            creds = blob.download_as_string()
            json_acct_info = json.loads(creds)
    print(json_acct_info)
    return json_acct_info