"""
  Integration with Google Spreadsheet

"""
import gspread

from importlib import import_module
auth = import_module('poc-auth')

SHEETS_API_SCOPE = ['https://spreadsheets.google.com/feeds',
                    'https://www.googleapis.com/auth/drive']

class SpreadsheetIntegration:

    # gc = None
    main_worksheet = None

    def __init__(self, spreadsheet_id: str, cred_file_path=None, cred_remote_function=None):
      local_usage = True if cred_file_path else False
      self.creds_key_json = auth.get_json_auth_key(local=local_usage, local_path=cred_file_path, remote_function=cred_remote_function)
      if self.creds_key_json:
        print('set credentials file')
        self.set_credentials(auth.transform_credentials(self.creds_key_json, SHEETS_API_SCOPE))
      self.spreadsheet_id = spreadsheet_id

    def set_credentials(self, credentials):
      self.gc = gspread.authorize(credentials)

    def set_main_worksheet(self, worksheet_name: str):
      self.main_worksheet = self.gc.open_by_key(self.spreadsheet_id).worksheet(worksheet_name)

    def next_empty_row(self, ref_row, last_row, ref_column, worksheet=None):
      if not worksheet: worksheet = self.main_worksheet
      for index, cell in enumerate(worksheet.range(ref_row, ref_column, last_row, ref_column)):
          if cell.value == '':
              return index + ref_row

    def get_last_registry(self, worksheet=None):
      if not worksheet: worksheet = self.main_worksheet
      row = len(worksheet.get_all_values())
      return worksheet.row_values(row)

    def get_cell_value(self, row: int, column: int, worksheet=None):
      if not worksheet: worksheet = self.main_worksheet
      return worksheet.cell(row, column).value

    def get_cell_by_column_value(self, column_value: str, row: int, worksheet=None):
      if not worksheet: worksheet = self.main_worksheet
      return worksheet.find(column_value, in_row=row)

    def get_cell_by_row_value(self, row_value: str, column: int, worksheet=None):
      if not worksheet: worksheet = self.main_worksheet
      return worksheet.find(row_value, in_column=column)

    def update_cell_value(self, row: int, column: int, value: str, worksheet=None):
      if not worksheet: worksheet = self.main_worksheet
      worksheet.update_cell(row, column, value)
