import json
from google.oauth2.service_account import Credentials

def get_json_auth_key(local=False, local_path=None, remote_function=None):
    if local:
        if local_path == '':
            raise ValueError('for local option, local file path is required')
        print('using local creds file')
        with open(local_path, 'r') as local_json:
            return json.loads(local_json.read())
    elif remote_function:
      print('using remote function creds file')
      result = remote_function()
      if isinstance(result, str):
        return json.loads(result)
      return result
    else:
        print('skipping credentials')
        return None

def transform_credentials(creds_key_json: dict, scope: list):
  return Credentials.from_service_account_info(creds_key_json, scopes=scope)
